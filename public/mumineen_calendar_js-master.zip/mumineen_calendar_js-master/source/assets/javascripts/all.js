//= require lazy
//= require react-with-addons
//
//= require_tree ./_lib
//= require_tree ./_components
//= require app
